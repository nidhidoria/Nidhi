package com.sbi.project.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sbi.project.layer2.*;

@Service
public interface ApplicantService {

	void createApplicationService(Applicant app);
	List<Applicant> getAllApplicants();
	void modifyApplication(Applicant applicant);
	void removeApplication(int applicantId);
}
