package com.sbi.project.layer5;

import java.io.PrintWriter;

import org.apache.catalina.connector.Response;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;




@RestController
@RequestMapping("/greetings")
public class GreetingController {
	
	@RequestMapping("/greet")   //   http://localhost:8080/greetings/greet
	public String GreetingMessage()
	{
		return "Greeting from SpringWeb Rest Based Application";
	}
	
	@RequestMapping("/welcome")   //   http://localhost:8080/greetings/greet
	public String WelcomeMessage()
	{
		return "Welcome from SpringWeb Rest Based Application";
	}
	
	@RequestMapping("/regards")   //   http://localhost:8080/greetings/greet
	public String RegardsMessage()
	{
		return "Regards from SpringWeb Rest Based Application";
	}
	
	
}


