package com.sbi.project.layer5;

import java.time.LocalDate;
import java.util.ArrayList;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/emp")

public class EmployeeController {
	
	ArrayList<Employee> staff= new ArrayList<Employee>();
	public EmployeeController()
	{
		System.out.println("EmployeeController() constructor.......");
		Employee emp1 = new Employee(101,"Jack","President",LocalDate.of(2000, 01, 13),80000,40);
		Employee emp2 = new Employee(102,"Jhil","Manager",LocalDate.of(2008, 05, 18),70000,30);
		Employee emp3 = new Employee(103,"Jane","Account",LocalDate.of(2012, 8, 13),60000,35);
		Employee emp4 = new Employee(104,"Jenny","Manager",LocalDate.of(2015, 8, 3),70000,32);
		Employee emp5 = new Employee(105,"John","Account",LocalDate.of(2012, 9, 1),60000,35);
		staff.add(emp1);
		staff.add(emp2);
		staff.add(emp3);
		staff.add(emp4);
		staff.add(emp5);
	}
		
	@RequestMapping("/getemps")   
	public ArrayList<Employee> getAllEmployee()
	{	
		
		return staff;
	}
	
	
	@RequestMapping("/getemp/{eno}")   
	public Employee getEmployee(@PathVariable("eno") int employeenumbertosearch)
	{	
		System.out.println("/{getemp}");
		boolean employeeFound = false;
		Employee empObj = null;
		for(int i=0; i<staff.size();i++)
		{
			empObj = staff.get(i);
			if(empObj.getEmployeeNumber() == employeenumbertosearch)
			{	employeeFound =true;
				break;}
		}
	
		if(employeeFound== true)
		{	
			return empObj;
		}
		else
		{
			throw new RuntimeException("Employee Not Found");
		}
		
	}
	
	
	
	@RequestMapping("/deleteemp/{eno}")   
	public String deleteEmployee(@PathVariable("eno") int employeenumbertodelete)
	{	
		System.out.println("/{deleteemp}");
		boolean employeeFound = false;
		Employee empObj = null;
		for(int i=0; i<staff.size();i++)
		{
			empObj = staff.get(i);
			if(empObj.getEmployeeNumber() == employeenumbertodelete)
			{	
				employeeFound =true;
				staff.remove(i);
				break;}
			}
	
		if(employeeFound== true)
		{	
			return "Employee Object Deleted" +employeenumbertodelete;
		}
		else
		{
			return "Employee Object Not Found" +employeenumbertodelete;
		}
		
	}
	
	
	@RequestMapping("/updateemp")   
	public String updateEmployee(@RequestBody Employee employeeObjectToModify)
	{	
		System.out.println("/{updateemp}");
		boolean employeeFound = false;
		Employee empObj = null;
		for(int i=0; i<staff.size();i++)
		{
			empObj = staff.get(i);
			if(empObj.getEmployeeNumber() == employeeObjectToModify.getEmployeeNumber())
			{	
				employeeFound =true;
				staff.remove(i);
				staff.add(employeeObjectToModify);
				break;}
			}
	
		if(employeeFound== true)
		{	
			return "Employee Object Succesfully Modified" +employeeObjectToModify;
		}
		else
		{
			return "Employee Object Not Found" +employeeObjectToModify;
		}
		
	}
	
	
	
	@RequestMapping("/addemp")   
	public String addEmployee(@RequestBody Employee employeeObjectToAdd)
	{	
		System.out.println("/{addemp}");
		boolean employeeFound = false;
		Employee empObj = null;
		for(int i=0; i<staff.size();i++)
		{
			empObj = staff.get(i);
			if(empObj.getEmployeeNumber() == employeeObjectToAdd.getEmployeeNumber())
			{	
				employeeFound =true;
				break;
			}
		
		}
		if(employeeFound== true)
		{	
			return "Employee Already Exsist" +employeeObjectToAdd;
		}
		else
		{	
			staff.add(employeeObjectToAdd);
			return "Employee Object added" +employeeObjectToAdd;
		}
		
	}
	
}
	
	

