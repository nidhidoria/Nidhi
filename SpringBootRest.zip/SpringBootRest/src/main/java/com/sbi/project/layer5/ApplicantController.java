package com.sbi.project.layer5;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer4.ApplicantService;

@RestController
@RequestMapping("/applicants")

public class ApplicantController {
	
	@Autowired
	ApplicantService applicantservice;
	
	List<Applicant> allApplicant= new ArrayList<Applicant>();
	
	
	
	public ApplicantController()
	{
		System.out.println("ApplicantController() constructor.......");
		
	}
		
	@RequestMapping("/getapplicants")   
	public List<Applicant> getAllApplicant()
	{	
		
		return applicantservice.getAllApplicants();
	}
	
	
	@RequestMapping("/getapplicant/{ano}")   
	public Applicant getApplicant(@PathVariable("ano") int applicantnotosearch)
	{	
	
		
		allApplicant = applicantservice.getAllApplicants();
		System.out.println("/{getapplicant}");
		boolean applicantfound = false;
		Applicant applicantObj = null;
		for(int i=0; i<allApplicant.size();i++)
		{
			applicantObj = allApplicant.get(i);
			System.out.println("Happy New Year");
			if(applicantObj.getApplicantId() == applicantnotosearch)
			{	
				System.out.println("Happy New Year");
				applicantfound =true;
				break;
			}
		}
	
		if(applicantfound== true)
		{	
			return applicantObj;
			
		}
		else
		{
			throw new RuntimeException("Applicant Not Found");
		}
		
	}
	
	
//	
	@RequestMapping("/deleteapplicant/{eno}")   
	public String deleteApplicant(@PathVariable("eno") int applicantnotodelete)
	{	
		allApplicant = applicantservice.getAllApplicants();
		System.out.println("/{deleteemp}");
		boolean applicantFound = false;
		Applicant appObj = null;
		for(int i=0; i<allApplicant.size();i++)
		{
			appObj = allApplicant.get(i);
			if(appObj.getApplicantId() == applicantnotodelete)
			{	
				applicantFound =true;
				
				
				break;
			}
		}		
			if(applicantFound== true)
			{	
			applicantservice.removeApplication(applicantnotodelete);
			System.out.println("DEleteing");
			return "Applicant Object Deleted" +applicantnotodelete;
			}
			else
			{
				return "Applicant Object Not Found" +applicantnotodelete;
			}
		
		
	}
		
	
	
	@RequestMapping("/updateapplicant")   
	public String updateApplicant(@RequestBody Applicant appObjtomodify)
	{	
		allApplicant = applicantservice.getAllApplicants();
		System.out.println("/{updateapp}");
		boolean applicantfound = false;
		Applicant appObj = null;
		for(int i=0; i<allApplicant.size();i++)
		{
			appObj = allApplicant.get(i);
			if(appObj.getApplicantId() == appObjtomodify.getApplicantId())
			{	
				applicantfound =true;
				
				applicantservice.removeApplication(i);
				applicantservice.createApplicationService(appObj);
				
				break;
			}
		}
	
		if(applicantfound== true)
		{	
			return "Employee Object Succesfully Modified" +appObjtomodify;
		}
		else
		{
			return "Employee Object Not Found" +appObjtomodify;
		}
		
	}
	
	
	
	@RequestMapping("/addapplicant")   
	public String addApplicant(@RequestBody Applicant applicantObjecttoadd)
	{	
		List<Applicant> allApplicant1 = applicantservice.getAllApplicants();
		System.out.println("/{addapplicant}");
		boolean applicantfound = false;
		Applicant appObj = null;
		for(int i=0; i<allApplicant1.size();i++)
		{	
			System.out.println("for");
			appObj = allApplicant1.get(i);
			if(appObj.getApplicantId() == applicantObjecttoadd.getApplicantId())
			{	
				applicantfound =true;
				break;
			}
		
		}
		if(applicantfound== true)
		{	
			return "Applicant Already Exsist" +applicantfound;
		}
		else
		{	
			//allApplicant.add(appObj);
			System.out.println("adddd}");
			applicantservice.createApplicationService(appObj);
			return "Employee Object added" +applicantObjecttoadd;
			
		}
		
	}
	
}
	
	

