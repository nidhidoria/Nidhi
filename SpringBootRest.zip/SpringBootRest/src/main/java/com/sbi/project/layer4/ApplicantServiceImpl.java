package com.sbi.project.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.project.layer2.*;
import com.sbi.project.layer3.*;
import com.sbi.project.layer4.*;

@Service
public class ApplicantServiceImpl implements ApplicantService {
	
	
	@Autowired
	ApplicantRepository appRepo;
	

	public void createApplicationService(Applicant app) {
		
		appRepo.createApplication(app);
		System.out.println("ApplicantServiceImpl.... created the Applicant");
	}


	@Override
	public List<Applicant> getAllApplicants() {
		// TODO Auto-generated method stub
		return appRepo.findAllApplicants();
	}


	@Override
	public void modifyApplication(Applicant applicant) {
		// TODO Auto-generated method stub
		appRepo.modifyApplication(applicant);
	}


	@Override
	public void removeApplication(int applicantId) {
		// TODO Auto-generated method stub
		appRepo.removeApplication(applicantId);
	}
	
	

	

	
	
	
}
