package dao;

import java.util.Set;

import entity.Project;

public interface ProjectDAO
{
	void addProject(Project project);
	void modifyProject(Project prj);
	void deleteProject(int prjid);
	Project findProject(int prjid);
	Set<Project> findAllProject();
}