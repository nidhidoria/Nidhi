package entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="subscription")
public class Subscription {
	
	@Id
	@Column(name ="sub_Id")
	private int subscriptionid;
	
	@Column(name ="sub_name")
	private String subname;
	
	@Column(name ="sub_type")
	private String subtype;

	@ManyToMany
	@JoinTable(name="CustomerSubscriptionLink",
	joinColumns = {@JoinColumn(name = "sid")},
	inverseJoinColumns = {@JoinColumn(name = "cid")})
	Set<Customer> customers = new HashSet<Customer>();
	
	
	public Set<Customer> getCustomers() {
		return customers;
	}

	public void setCustomers(Set<Customer> customers) {
		this.customers = customers;
	}

	public int getSubscriptionid() {
		return subscriptionid;
	}

	public void setSubscriptionid(int subscriptionid) {
		this.subscriptionid = subscriptionid;
	}

	public String getSubname() {
		return subname;
	}

	public void setSubname(String subname) {
		this.subname = subname;
	}

	public String getSubtype() {
		return subtype;
	}

	public void setSubtype(String subtype) {
		this.subtype = subtype;
	}

	

}
