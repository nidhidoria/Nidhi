package entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="customer")
public class Customer {
	
	@Id
	@Column(name ="cust_Id")
	private int customerId;
	
	@Column(name ="cust_name")
	private String customerName;
	
	@Column(name ="cust_email")
	private String emailAddress;
	
	@ManyToMany(fetch = FetchType.EAGER,cascade = CascadeType.ALL)
	@JoinTable(name="CustomerSubscriptionLink",
	joinColumns = {@JoinColumn(name = "cid")},
	inverseJoinColumns = {@JoinColumn(name = "sid")})
	Set<Subscription> subscriptiones = new HashSet<Subscription>();
	
	
	

	public Set<Subscription> getSubscriptiones() {
		return subscriptiones;
	}

	public void setSubscriptiones(Set<Subscription> subscriptiones) {
		this.subscriptiones = subscriptiones;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	
	
	
	
}
