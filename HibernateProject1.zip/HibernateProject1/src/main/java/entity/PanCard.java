package entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "PAN_CARD")
public class PanCard {
	
	@Id
	@Column(name="Pan_No")
	private String panNo;
	

	
	@Column(name="dob")
	private LocalDate birthDate;
	
	@OneToOne //(cascade = CascadeType.PERSIST)
	@JoinColumn(name="emp_id")
	private Employee emp;
	

	public PanCard(String panNo,  LocalDate birthDate) {
		super();
		this.panNo = panNo;
		
		this.birthDate = birthDate;
	}
	
	
	
	public Employee getEmp() {
		return emp;
	}



	public void setEmp(Employee emp) {
		this.emp = emp;
	}



	public String getPanNo() {
		return panNo;
	}

	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}


	public LocalDate getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(LocalDate birthDate) {
		this.birthDate = birthDate;
	}
	
	
	

}

