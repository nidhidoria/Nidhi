package Strategy1;

import org.junit.jupiter.api.Test;

import dao.BaseDAOimpl;
import strategy1.BankAccount;
import strategy1.CreditCard;

public class StrategyOneTest {
	
	BaseDAOimpl basedao = new BaseDAOimpl();
	
	@Test
	public void testAddBankAccountDetails()
	{
		BankAccount baObj = new BankAccount();
		baObj.setOwner("Jen");
		baObj.setAcnumber("6253251352");
		baObj.setBankname("SBI");
		baObj.setIfsccode("SBIN856641");
		
		basedao.persist(baObj);
	}
	
	@Test
	public void testAddCreaditCardDetails()
	{
		CreditCard ccObj = new CreditCard();
		ccObj.setOwner("Jane");
		ccObj.setAcnumber("6253584634545");
		ccObj.setCardType("VISA");
		ccObj.setExpiryMonth("June");
		ccObj.setExpiryYear("2024");
		
		basedao.persist(ccObj);
	}

}
