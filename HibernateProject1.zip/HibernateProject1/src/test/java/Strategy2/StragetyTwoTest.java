package Strategy2;

import org.junit.jupiter.api.Test;

import dao.BaseDAO;

import dao.BaseDAOimpl;
import strategy2.BankAccount;
import strategy2.CreditCard;

public class StragetyTwoTest {

	BaseDAO baseDao = new BaseDAOimpl();
	
	
	@Test
	public void testAddBankAccountDetails()	{
		BankAccount baObj = new BankAccount();
		baObj.setOwner("Jack");
		baObj.setAcnumber("123123123123");;
		baObj.setBankname("ICICI");
		baObj.setIfsccode("ICICI123");
		baseDao.persist(baObj);
	}
	
	@Test
	public void testAddCreditCardDetails()	{
		CreditCard ccObj = new CreditCard();
		ccObj.setOwner("Jane");
		ccObj.setAcnumber("623623623623");;
		ccObj.setCardType("Coral Card");
		ccObj.setExpiryMonth("Jan");
		ccObj.setExpiryYear("2024");
		baseDao.persist(ccObj);
	}
}