import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.junit.jupiter.api.Test;

import entity.Department;
import entity.Employee;
import entity.Passport;
import entity.Project;

public class CrudTestingOneToMany {

	

	EntityManagerFactory emf;
	EntityManager em ;
	public CrudTestingOneToMany()
	{
		System.out.println("CrudTesting()....");
		// TODO Auto-generated method stub
				System.out.println("Trying to read persistence.xml file...");
				
				//3
				this.emf = Persistence.createEntityManagerFactory("MyJPA");
				System.out.println("EntityManagerFactory created....");
				
				this.em = emf.createEntityManager();
				System.out.println("EntityManager created....");

	}
	
	@Test
	public void addSingleDepartmentTest()
	{
		EntityTransaction tx = em.getTransaction();
		Department dept1 = new Department("Payment","Delhi");
		tx.begin();
		em.persist(dept1);
		tx.commit();
		
	}
	
	@Test
	public void addNewDepartmentwithNewEmployeeSet()
	{
		Passport p1= new Passport();
		p1.setIssuedBy("Govt. Of. China");
		p1.setPassportIssuedDate(LocalDate.of(2022, 9, 28));
		p1.setPassportExpiryDate(LocalDate.of(2032,9, 28));
		
		Passport p2= new Passport();
		p2.setIssuedBy("Govt. Of. USA");
		p2.setPassportIssuedDate(LocalDate.of(2002, 7, 2));
		p2.setPassportExpiryDate(LocalDate.of(2012,7, 2));
		
		Passport p3= new Passport();
		p3.setIssuedBy("Govt. Of. India");
		p3.setPassportIssuedDate(LocalDate.of(2021, 9, 01));
		p3.setPassportExpiryDate(LocalDate.of(2031,9, 01));
		
		Department d1 = new Department("INB", "Belapur");
		
		Employee e1 = new Employee("Kamwar", "President", LocalDate.of(2017, 1, 16), 100000, 25, p1, d1);
		Employee e2 = new Employee("Iqbal", "Vice President", LocalDate.of(2016, 3, 18), 90000, 30, p2, d1);
		Employee e3 = new Employee("Rubi", "Manager", LocalDate.of(2020, 12, 6), 800000, 31, p3, d1);
		
		p1.setEmp(e1);
		p2.setEmp(e2);
		p3.setEmp(e3);
		
		Set<Employee> temp = new HashSet<Employee>();
		temp.add(e1);
		temp.add(e2);
		temp.add(e3);
		
		d1.setStaff(temp);
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		em.persist(d1);
		tx.commit();
		
		
	}
	
	@Test
	public void showAllDepartment()
	{
		Query query = em.createQuery("from Department");
		List<Department> list = query.getResultList();
		Set<Department> dptset = new HashSet(list);
		
		//	List<Project> staff = query.getResultList();
			for (Department dept : dptset) {
				System.out.println("Department ID 		: "+dept.getDepartmenttno());
				System.out.println("Department Name   	: "+dept.getDepartmentname());
				System.out.println("DEpartment Location	: "+dept.getDepartmentloc());
				System.out.println("**************************************************");
		
	}
	
	
	}
}
