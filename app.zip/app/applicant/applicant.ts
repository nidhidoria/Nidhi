export class applicant{
    appid :number=0;
    appName : String = "";
    appAcNO : String ="";
    appStatus : String = "Applied";
   }