import { Component, OnInit } from '@angular/core';
import { applicant } from './applicant';

@Component({
  selector: 'app-applicant',
  templateUrl: './applicant.component.html',
  styleUrls: ['./applicant.component.css']
})
export class ApplicantComponent implements OnInit {

  appObj : applicant = new applicant();

  Msg : String="";
  
  constructor() { }

  ngOnInit(): void {
  }

  applicantArray : applicant[] = [
    {
      appid:1,appName:"Jhil",appAcNO:"12563856",appStatus:"Applied"
    },
    {
      appid:2,appName:"Jack",appAcNO:"85965478",appStatus:"Applied"
    },
    {
      appid:3,appName:"John",appAcNO:"95863452",appStatus:"Applied"
    },
    {
      appid:4,appName:"Jeny",appAcNO:"98563145",appStatus:"Applied"
    },
    {
      appid:5,appName:"Johny",appAcNO:"874563152",appStatus:"Applied"
    },
 
  ]


  addApplicant()
  {
    this.applicantArray.push(this.appObj);
  }

  rejectApplicant(applicantToberejected : applicant)
  {
    this.Msg = applicantToberejected.appName+  " Applicant Rejected. Reason is Incorrect Fromat";
   //this.Msg=event.target.value;
   applicantToberejected.appStatus="Rejected";
   this.applicantArray=this.applicantArray.filter(item=>item!==applicantToberejected);
   
  }
  selectChangeHandler(event:any,applicantToberejected : applicant)
  {
    this.Msg = " Applicant Rejected. Reason is " +event.target.value ;
    applicantToberejected.appStatus="Rejected";
  }

 

  approveApplicant(applicantTobeapproved : applicant)
  {
   
  //  this.applicantArray.push(item=>item!==applicantToberejected);
     applicantTobeapproved.appStatus="Approved";
     this.Msg = applicantTobeapproved.appName+  "  Applicant Approved ";
  }

}
