import { Component, OnInit } from '@angular/core';
import { CurrencyConverterService } from '../currency-converter.service';

@Component({
  selector: 'app-currency-converter',
  templateUrl: './currency-converter.component.html',
  styleUrls: ['./currency-converter.component.css']
})
export class CurrencyConverterComponent implements OnInit {


  src : string="";
  trgt : string="";
  amt : number=0;
  answer : number=0;
  constructor(private currcon:CurrencyConverterService) { }

  ngOnInit(): void {
  }

  convert()
  {
    console.log("convert() invoked...");
   
      if(this.src.match("India") && this.trgt.match("United State of America"))
      {
    this.answer = this.currcon.converttoUSD(this.src,this.trgt,this.amt);
      }
     else if(this.src.match("India") && this.trgt.match("Austraila"))
      {
    this.answer = this.currcon.converttoAUD(this.src,this.trgt,this.amt);
      }
    else if(this.src.match("India") && this.trgt.match("Canada"))
      {
      this.answer = this.currcon.converttoCAD(this.src,this.trgt,this.amt);
      }
      else if(this.src.match("India") && this.trgt.match("United Kingdom"))
      {
      this.answer = this.currcon.converttoPOUND(this.src,this.trgt,this.amt);
      }
       


    else if(this.trgt.match("India"))
    {
    this.answer = this.currcon.converttoINR(this.src,this.trgt,this.amt);
    }
    else
    {
      this.answer=0;
    
    }
  }
}
