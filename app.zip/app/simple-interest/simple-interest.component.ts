import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-simple-interest',
  templateUrl: './simple-interest.component.html',
  styleUrls: ['./simple-interest.component.css']
})
export class SimpleInterestComponent implements OnInit {
  
  principal:number =10000;  //Data Members
  years:number = 1;
  ROI:number =7;
  si: number =0;
  
  constructor() { }

  ngOnInit(): void {
  }


  calculateSimpleInt()   //Member Function
  {
    console.log("calculateSimpleInt() Invoke..");
    this.si = (this.principal*this.years*this.ROI)/100;

  }

}
