import { invokeInstruction } from '@angular/compiler/src/render3/view/util';
import { Component, OnInit } from '@angular/core';
import { NewapplicantService } from '../newapplicant.service';
import { address } from '../newapplicant/address';
import { newapplicant } from '../newapplicant/newapplicant';


@Component({
  selector: 'app-apply',
  templateUrl: './apply.component.html',
  styleUrls: ['./apply.component.css']
})
export class ApplyComponent implements OnInit {
  
  applicant : newapplicant = new newapplicant();
  add1 : address = new address();
  add2 : address = new address();
  msg :any ="";

  constructor(private applicantservcieobj : NewapplicantService) { }

  ngOnInit(): void {
  }

  applyforBankAccount()
  { 
    this.add1.addressType="Home";
    this.add2.addressType="Office";
    this.applicant.applicationStatus ="Applied";
    this.applicant.addressList.push(this.add1);
    this.applicant.addressList.push(this.add2);
    console.log("applyforBankAccount invoke.....");
    
    this.applicantservcieobj.addApplicantService(this.applicant).subscribe(
      (data:any) =>
      {
        this.msg= data;
        console.log(data);
        console.log(this.msg);
      },
      (err) =>
      {
        console.log(err);
      }
    )
  }

}
