import { TestBed } from '@angular/core/testing';

import { NewapplicantService } from './newapplicant.service';

describe('NewapplicantService', () => {
  let service: NewapplicantService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NewapplicantService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
