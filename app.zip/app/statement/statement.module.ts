import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MonthlyStatementComponent } from './monthly-statement/monthly-statement.component';
import { WeeklyStatementComponent } from './weekly-statement/weekly-statement.component';
import { YearlyStatementComponent } from './yearly-statement/yearly-statement.component';



@NgModule({
  declarations: [
    MonthlyStatementComponent,
    WeeklyStatementComponent,
    YearlyStatementComponent
  ],
  imports: [
    CommonModule
  ]
})
export class StatementModule { }
