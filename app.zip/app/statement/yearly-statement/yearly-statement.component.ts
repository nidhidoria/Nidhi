import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-yearly-statement',
  templateUrl: './yearly-statement.component.html',
  styleUrls: ['./yearly-statement.component.css']
})
export class YearlyStatementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
