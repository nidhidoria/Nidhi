import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username:string="";
  password:string=""; 
  msg:string="";
  constructor() { }

  ngOnInit(): void {
  }
 authenticateUSer()
 {
   console.log(this.username);
   console.log(this.password);
   if(this.username == 'admin' && this.password =='password')
   {
      this.msg = "Welcome To Admin Dashboard";
   }
   else{
     this.msg = "Welcome to User Dashboard";
   }
 }

}