import { Component, OnInit } from '@angular/core';
import { CalculatorService } from '../calculator.service';

@Component({
  selector: 'app-calculator',
  templateUrl: './calculator.component.html',
  styleUrls: ['./calculator.component.css']
})
export class CalculatorComponent implements OnInit {


  a : number=0;
  b : number=0 ;
  answer : number=0;
  constructor(private calcServ : CalculatorService) { 
    console.log('Calculator Component ...setting Calculator Service')
  }

  ngOnInit(): void {
  }

  addNumbers()
  {
    console.log('local addNumbers()');
    this.answer=this.calcServ.addTwoNoService(this.a,this.b);
    
  }

  subtractNumbers()
  {
    console.log('local subtractNumbers()');
    this.answer= this.calcServ.subtractTwoNoService(this.a,this.b);
    
  }

  multiplyNumbers()
  {
    console.log('local multiplyNumbers()');
    this.answer= this.calcServ.multiplyTwoNoService(this.a,this.b);
    
  }

  divideNumbers()
  {

    console.log('local divideNumbers()');
    this.answer=this.calcServ.divideTwoNoService(this.a,this.b);
   
  }
}
