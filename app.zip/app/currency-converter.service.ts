import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CurrencyConverterService {

  constructor() { }


  converttoUSD(src:string,trg:string,z:number):number{
    console.log('convertCurrencyservice.converttoUSD invoked()..')
    
    return z/70; 
  }

  converttoINR(src:string,trg:string,z:number):number
  {
    console.log('convertCurrencyservice.converttoINR invoked()..')
    if(trg="India")
    {
       if(src="United State of America")
       {
       return z*70; 
        }
        else if (src="Canada")
        {
          return z*60;
        }
        else if (src="United Kingdom")
        {
         return z*90;
       }
         else if (src="Austraila")
        {
        return z*50;
        }
    
    }
    return 0;
  }

  converttoAUD(src:string,trg:string,z:number):number{
    console.log('convertCurrencyservice.converttoAUD invoked()..')
    
    return z/50; 
  }

  converttoCAD(src:string,trg:string,z:number):number{
    console.log('convertCurrencyservice.converttoCAD invoked()..')
    
    return z/60; 
  }


  converttoPOUND(src:string,trg:string,z:number):number{
    console.log('convertCurrencyservice.converttoPOUND invoked()..')
    
    return z/90; 
  }
}
