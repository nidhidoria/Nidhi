import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CalculatorService {

  constructor() { }

  addTwoNoService(x:number,y:number):number{
    console.log('CalculatorService,addition invoked()..')
    return x+y;
  }

  subtractTwoNoService(x:number,y:number):number{
    console.log('CalculatorService,subtract invoked()..')
    return x-y;
  }

  multiplyTwoNoService(x:number,y:number):number{
    console.log('CalculatorService,multiply invoked()..')
    return x*y;
  }

  divideTwoNoService(x:number,y:number):number{
    console.log('CalculatorService,divide invoked()..')
    return x/y;
  }

}
