export class Payee{
    payid :number=0;
    payacno : number = 0;
    payname : string ="";
    ifsccode : string = "";
    nickname : string="";
}