import { Component, OnInit } from '@angular/core';
import { Payee } from './Payee';

@Component({
  selector: 'app-add-payee',
  templateUrl: './add-payee.component.html',
  styleUrls: ['./add-payee.component.css']
})
export class AddPayeeComponent implements OnInit {


  payeeObj : Payee = new Payee();
  reacno:number=0;
  errMsg:String="";

  payeeArray : Payee[] = [
    {
      "payid":1,"payacno":123456789,"payname":"Jack","ifsccode":"SBIN005","nickname":"ja"
    },
    {
      "payid":2,"payacno":85963542,"payname":"Jane","ifsccode" :"SBIN004","nickname":"jn"
    },
    {
      "payid":3,"payacno":86565234,"payname":"John","ifsccode" :"SBIN006","nickname":"jo"
    },
    {
      "payid":4,"payacno":745632599,"payname":"Jenny","ifsccode" :"SBIN009","nickname":"je"
    },
    {
      "payid":5,"payacno":365289651,"payname":"Jhil","ifsccode":"SBIN007","nickname":"ji"
    }

  ];




  constructor() { }

  ngOnInit(): void {
  }

  verfiyAccountno()
  {
    if(this.payeeObj.payacno != this.reacno)
    {
      this.errMsg = "Account No MisMatch";
    }
    else
    {
      this.errMsg = "";
    }
  }



  addPayee()
  {
    this.payeeArray.push(this.payeeObj);
  }

  deletePayee(payeeTobeDeleted:Payee)
  {
    console.log('Delete Payee' +payeeTobeDeleted.payid);
    this.payeeArray=this.payeeArray.filter(item=> item !== payeeTobeDeleted)
  }

  tempPayeeArray: Payee[] = this.payeeArray;
  tempPayeeArray2: Payee[] = this.payeeArray;

  reloadPayees(payeeFound: Payee)
  { 
    this.tempPayeeArray=this.tempPayeeArray2;
    this.tempPayeeArray  = this.tempPayeeArray.filter(item=>item.payname.match(payeeFound.payname));
    this.payeeArray = this.tempPayeeArray;

  }

 
}
