import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApprejectComponent } from './appreject.component';

describe('ApprejectComponent', () => {
  let component: ApprejectComponent;
  let fixture: ComponentFixture<ApprejectComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ApprejectComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ApprejectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
