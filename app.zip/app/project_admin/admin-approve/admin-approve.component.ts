import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { PrjApplicantService } from 'src/app/prj-applicant.service';
import { prjApplicant } from '../admin-home/prjApplicant';


@Component({
  selector: 'app-admin-approve',
  templateUrl: './admin-approve.component.html',
  styleUrls: ['./admin-approve.component.css']
})
export class AdminApproveComponent implements OnInit {
  applicant: prjApplicant=new prjApplicant();

  msg:string="";
  selectedId: any;
   anyData: any;
 

 constructor(private applicantserviceObj : PrjApplicantService,private _activatedRoute: ActivatedRoute, private router: Router) { }
  prjapplicant: prjApplicant = new prjApplicant();
  ngOnInit(): void {
        console.log("adminapprove ngOninit method()...");
        this._activatedRoute.paramMap.subscribe( params=> {
         this.selectedId=params.get('id');
           this.applicantserviceObj.loadAllapplicantsService().subscribe(
            (data:prjApplicant[])=> {
            this.anyData = data.find(a=> a.applicantId==this.selectedId);
           this.applicant = this.anyData;
            })
          });
  
}

  viewapplicant(appid : number)
  {
    console.log("viewapplicant() method")
    this.applicantserviceObj.viewsingleapplicant(appid);
  
  }

  onBack():void {
    this.router.navigate(['/adminhome']);
  }


  }


  // reject():void{
   
  //       //   this.router.navigate(['/adminreject'])
  //       console.log("adminreject oninit method()...");
  //       this._activatedRoute.paramMap.subscribe( params=> {
  //        this.selectedId=params.get('id');
  //          this.applicantserviceObj.rejectaccount(this.selectedId).subscribe(
  //           (data:prjApplicant[])=> {
  //           this.anyData = data.find(a=> a.applicantId==this.selectedId);
  //          this.applicant = this.anyData;
  //     })
  //   });
  //     }


        
      
    
   


 



