import { JsonPipe } from '@angular/common';
import { parseI18nMeta } from '@angular/compiler/src/render3/view/i18n/meta';
import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { applicant } from 'src/app/applicant/applicant';
import { PrjApplicantService } from 'src/app/prj-applicant.service';
import { AdminApproveComponent } from '../admin-approve/admin-approve.component';
import { prjApplicant } from './prjApplicant';



@Component({
  selector: 'app-admin-home',
  templateUrl: './admin-home.component.html',
  styleUrls: ['./admin-home.component.css']
})
export class AdminHomeComponent implements OnInit {

  form: FormGroup;
  applicant:prjApplicant = new prjApplicant();
  applicantArray : prjApplicant[]=[];
  checkedIDs : []=[];
  num : []=[];
    msg:string="";
    selectedId: any;
   anyData: any;
   
  constructor(private applicantserviceObj : PrjApplicantService,private fb: FormBuilder,
        private _activatedRoute: ActivatedRoute, private router: Router)
         {
      this.form = this.fb.group({checkArray: this.fb.array([])
    })
   }
  
   


  ngOnInit(): void {
   this.showPendingApplication();
  }

  showPendingApplication()
  {
    console.log("showPendingApplication() method")
    this.applicantserviceObj.loadAllPendingapplicantsService().subscribe(
      (data:prjApplicant[]) =>
      {
        this.applicantArray=data;
      },
      (err) =>
      {
        console.log(err);
      }

    )
  }
  viewapplicant(appid : number)
  {
    console.log("viewapplicant() method")
    this.applicantserviceObj.viewsingleapplicant(appid);
  
  }
  

  onCheckboxChange(e : any) {
   const checkArray: FormArray = this.form.get('checkArray') as FormArray;
    if (e.target.checked) {
      checkArray.push(new FormControl(e.target.value));
    } else {
      let i: number = 0;
      checkArray.controls.forEach((item: any) => {
        if (item.value == e.target.value) {
          checkArray.removeAt(i);
          return;
        }
        i++;
      });
    }
  //  console.log(checkArray.at(1));

  }
 


  submitForm() {

  
  
    // const checkArray: FormArray = this.form.get('checkArray') as FormArray;
    //const num:FormArray = this.form.get('num').value;
  //  console.log("hi" +this.form.value);
   // foreach(this.form.value => this.approvemultipleaccount(this.form.value)); 
  //  console.log("form submited", +this.form.value);
   
    //this.num = this.form.value;
    //console.log(this.form.get("applicantId")?.value);
   // console.log(this.form.getRawValue("applicant.applicantId").value);
   // console.log(this.fb.array);
   // console.log(this.checkedIDs);
  //    console.log('ID:' + this.form.get('applicant.applicantId').value);
   //  console.log(this.num);
   console.log(this.form.value);
  // i:Number;
  // this.i = <Number> this.form.value;
 //  console.log(this.form.get("applicantId").value);
 //console.log();

  //let appid : prjApplicant[];
  //  appid = this.form.value;
    console.log(JSON.stringify(this.form.value));
    // const myObj = JSON.stringify(this.form.value);
    // locavalStorage.setItem("test",myObj);
    var obj = JSON.stringify(this.form.value);
   // var str = JSON.parse(obj);
  //  console.log(str);
  var numarray=[];
length= obj.length;
for(var i=0;i<length;i++)
{
  numarray.push(parseInt(obj[i]));
 
}
    
   
  }
  


  approvemultipleaccount(x:number): void {

    console.log("Multiple account creation  maethod()...");
  //  this._activatedRoute.paramMap.subscribe( params=> {
  //  appid :  Array<number>;
 //   console.log(this.id);

    this.selectedId=x;
   // console.log(this.numArray[1]);
    this.applicantserviceObj.addaccount(this.applicant,this.selectedId).subscribe(
    (data:any) =>
    {
      this.msg= data;
      console.log(data);
      console.log(this.msg);
    },
    (err) =>
    {
      console.log(err);
    })
  
  }
 
  }
