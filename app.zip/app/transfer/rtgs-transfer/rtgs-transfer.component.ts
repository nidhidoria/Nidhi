import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rtgs-transfer',
  templateUrl: './rtgs-transfer.component.html',
  styleUrls: ['./rtgs-transfer.component.css']
})
export class RtgsTransferComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
