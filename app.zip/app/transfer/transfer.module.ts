import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ImpsTransferComponent } from './imps-transfer/imps-transfer.component';
import { RtgsTransferComponent } from './rtgs-transfer/rtgs-transfer.component';
import { NeftTransferComponent } from './neft-transfer/neft-transfer.component';
import { LoginComponent } from '../user/login/login.component';



@NgModule({
  declarations: [
    ImpsTransferComponent,
    RtgsTransferComponent,
    NeftTransferComponent
  ],
  imports: [
    CommonModule
  ],
  exports:[
    ImpsTransferComponent,
    NeftTransferComponent
  ]
 
})
export class TransferModule { }
