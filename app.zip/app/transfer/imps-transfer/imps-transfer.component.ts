import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-imps-transfer',
  templateUrl: './imps-transfer.component.html',
  styleUrls: ['./imps-transfer.component.css']
})
export class ImpsTransferComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
