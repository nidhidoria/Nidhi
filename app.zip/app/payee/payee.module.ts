import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddPayeeComponent } from './add-payee/add-payee.component';
import { ViewPayeeComponent } from './view-payee/view-payee.component';
import { DeletePayeeComponent } from './delete-payee/delete-payee.component';
import { ViewAllPayeeComponent } from './view-all-payee/view-all-payee.component';



@NgModule({
  declarations: [
    AddPayeeComponent,
    ViewPayeeComponent,
    DeletePayeeComponent,
    ViewAllPayeeComponent
  ],
  imports: [
    CommonModule
  ]
})
export class PayeeModule { }
