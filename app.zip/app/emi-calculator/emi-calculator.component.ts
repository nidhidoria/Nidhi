import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emi-calculator',
  templateUrl: './emi-calculator.component.html',
  styleUrls: ['./emi-calculator.component.css']
})
export class EmiCalculatorComponent implements OnInit {



  loanamount : number =0;
  tenure : number=0;
  roi = 0;
  emi =0;

  constructor() { }

  ngOnInit(): void {
  }


  calculateEMI()
  {   
        this.emi = this.loanamount * (this.roi/12/100) * (((1 + (this.roi/12/100))^this.tenure) /
        ((1+(this.roi/12/100))^this.tenure)-1 );
  }
}
