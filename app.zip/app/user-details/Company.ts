export class Company {
    name: string="Romaguera-Crona";
    catchPhrase:  string="Multi-layered client-server neural-net";
    bs:  string="harness real-time e-markets";
  }