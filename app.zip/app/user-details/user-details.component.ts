import { Component, OnInit } from '@angular/core';
import { UserDetailsService } from '../user-details.service';
import { UserDetails } from './UserDetails';

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.css']
})
export class UserDetailsComponent implements OnInit {

  constructor(private uds: UserDetailsService) { }
  userDetails: UserDetails= new UserDetails();
  userDetailsArray: UserDetails[]=[];
  
  ngOnInit(): void {
  }
  tempUserId: number=1;
  showUserDetails() {
      this.uds.fetchUserDetailsService(this.tempUserId).subscribe(
          (data:UserDetails) =>
          {
                this.userDetails = data;
                console.log(data);
          },
          (err) => 
          {
            console.log(err);
          }
    ); //end of subscribe
  }

  showAllUsersDetails() {
    this.uds.fetchAllUsersDetailsService().subscribe(
        (data:UserDetails[]) =>
        {
              this.userDetailsArray = data;
              console.log(data);
        },
        (err) => 
        {
          console.log(err);
        }
  ); //end of subscribe
}

}



/*

    class Abc
    {
       int k;

        ( i,  j)=>
        {
            k = i+j;
        }
    }

    Abc a = new Abc();
    a.fun(10,20);

*/