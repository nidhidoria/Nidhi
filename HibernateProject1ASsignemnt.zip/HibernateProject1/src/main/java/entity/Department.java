package entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="dept_tbl2")
public class Department {

	@Id
	@GeneratedValue
	@Column(name="deptno")
	private int departmenttno;
	
	@Column(name="dname")
	private String departmentname;
	
	@Column(name="location")
	private String departmentloc;
	
	@OneToMany(mappedBy = "dept",cascade = CascadeType.ALL)	//Assosciation 
	Set<Employee> staff =new HashSet<Employee>();
	

	public Set<Employee> getStaff() {
		return staff;
	}

	public void setStaff(Set<Employee> staff) {
		this.staff = staff;
	}

	public Department() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Department(String departmentname, String departmentloc) {
		super();
		
		this.departmentname = departmentname;
		this.departmentloc = departmentloc;
	}

	public int getDepartmenttno() {
		return departmenttno;
	}

	public void setDepartmenttno(int departmenttno) {
		this.departmenttno = departmenttno;
	}

	public String getDepartmentname() {
		return departmentname;
	}

	public void setDepartmentname(String departmentname) {
		this.departmentname = departmentname;
	}

	public String getDepartmentloc() {
		return departmentloc;
	}

	public void setDepartmentloc(String departmentloc) {
		this.departmentloc = departmentloc;
	}
	
	
	
	
	
	
	
}
