package entity;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="project_tbl")
public class Project
{
	@Id
	@GeneratedValue
	@Column(name="prj_ID")
	 int projectId;
	
	@Column(name="prj_title", length = 30)
	 String projectTitle;
	
	@Column(name="prj_ddl")
	 LocalDate projectDeadLine;
	
	@ManyToMany
	@JoinTable(name="EmployeeProjectLink",
	joinColumns = {@JoinColumn(name = "prjid")},
	inverseJoinColumns = {@JoinColumn(name = "empid")})
	Set<Employee> customers = new HashSet<Employee>();
	
	
	
	public Set<Employee> getCustomers() {
		return customers;
	}

	public void setCustomers(Set<Employee> customers) {
		this.customers = customers;
	}

	public Project() {
		super();
		System.out.println("Project created....");
	}
	
	public int getProjectId() {
		return projectId;
	}
	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}
	public String getProjectTitle() {
		return projectTitle;
	}
	public void setProjectTitle(String projectTitle) {
		this.projectTitle = projectTitle;
	}
	public LocalDate getProjectDeadLine() {
		return projectDeadLine;
	}
	public void setProjectDeadLine(LocalDate projectDeadLine) {
		this.projectDeadLine = projectDeadLine;
	}
	@Override
	public String toString() {
		return "Project [projectId=" + projectId + ", projectTitle=" + projectTitle + ", projectDeadLine="
				+ projectDeadLine + "]";
	}
	
	 
}