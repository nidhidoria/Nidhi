import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.jupiter.api.Test;

import entity.Address;
import entity.Customer;
import entity.Department;
import entity.Employee;
import entity.PanCard;
import entity.Passport;
import entity.Project;
import entity.Subscription;

public class AssignmentTest {
	
	

	EntityManagerFactory emf;
	EntityManager em ;
	public AssignmentTest()
	{
		System.out.println("CrudTesting()....");
		// TODO Auto-generated method stub
				System.out.println("Trying to read persistence.xml file...");
				
				//3
				this.emf = Persistence.createEntityManagerFactory("MyJPA");
				System.out.println("EntityManagerFactory created....");
				
				this.em = emf.createEntityManager();
				System.out.println("EntityManager created....");

	}
	
	
	@Test
	public void assignProjecttoExsistingEmployee()    //Employee Project Many To MAny Ralation ... EmployeeProjectLink Table
	{
		
	//	Employee e1= em.find(Employee.class,3);
		Employee e1= em.find(Employee.class,1);
		Project p1 = em.find(Project.class, 9);
	//	Project p2 = em.find(Project.class, 10);
		
		
		e1.getProject().add(p1);
	//	e1.getProject().add(p2);
		
			
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		em.merge(e1);
		tx.commit();
		
	}
	
	@Test
	public void addPanCardTest()
	{
		EntityTransaction tx = em.getTransaction();
		PanCard pan1 = new PanCard("BKPPD5463F", LocalDate.of(2000, 12, 2));
		
		tx.begin();
		em.persist(pan1);
		tx.commit();
		
	}
	
	@Test
	public void createNewEmployeeWithNewPancardTest() {   //OnetoOne one employee one pancard
		
		Employee theEmp = new Employee();
		theEmp.setName("KAvya");
		theEmp.setJob("account");
		theEmp.setJoiningDate(LocalDate.of(2020, 5, 11));
		theEmp.setSalary(30000);
		theEmp.setAge(25); 
		
		
		PanCard pan1 = new PanCard("CKPGJ%607J", LocalDate.of(2000, 3, 20));
		
		theEmp.setPancard(pan1);
		pan1.setEmp(theEmp);
		EntityTransaction tx = em.getTransaction();
		tx.begin();
			em.persist(theEmp);
			em.persist(pan1);
		tx.commit();
	}
	
	@Test
	public void addAddressTest()
	{
		EntityTransaction tx = em.getTransaction();
		Address add1 = new Address(203,"sector 11","navi mumbai","maharastra",400617);
		Address add2 = new Address(501,"kk nagr"," mumbai","maharastra",400785);
		Address add3 = new Address(407,"rto","ahmedabda","gujarat",380027);
	
		
		tx.begin();
		em.persist(add1);
		em.persist(add2);
		em.persist(add3);
		
		
		tx.commit();
		
	}
	
	@Test
	public void addNewEmployeewithNewAddressSet()
	{
//		Passport p1= new Passport();
//		p1.setIssuedBy("Govt. Of. China");
//		p1.setPassportIssuedDate(LocalDate.of(2022, 9, 28));
//		p1.setPassportExpiryDate(LocalDate.of(2032,9, 28));
//		
//		Passport p2= new Passport();
//		p2.setIssuedBy("Govt. Of. USA");
//		p2.setPassportIssuedDate(LocalDate.of(2002, 7, 2));
//		p2.setPassportExpiryDate(LocalDate.of(2012,7, 2));
//		
//		Passport p3= new Passport();
//		p3.setIssuedBy("Govt. Of. India");
//		p3.setPassportIssuedDate(LocalDate.of(2021, 9, 01));
//		p3.setPassportExpiryDate(LocalDate.of(2031,9, 01));
//		
//		Department d1 = new Department("INB", "Belapur");
		
		Address add1 = new Address(703,"Racecourse","Pune","maharastra",456789);
		Address add2 = new Address(601,"Highway"," Banglore","Karnatake",657886);
		Set<Address> addresstemp = new HashSet<Address>();
		addresstemp.add(add1);
		addresstemp.add(add2);
	
		Employee e1 = new Employee();
		e1.setName("Het");
		e1.setAge(23);
		e1.setJob("Anayst");
		e1.setAddress(addresstemp);
		e1.setJoiningDate(LocalDate.of(2020, 12, 4));
		e1.setSalary(80000);
	//	Employee e1 = new Employee("het", "analyst", LocalDate.of(2021, 12, 5), 56780, 24, p1, d1);
//		Employee e2 = new Employee("bhakti", "admin", LocalDate.of(2012, 3, 8), 780000, 21, p2, d1);
//		Employee e3 = new Employee("shrusthi", "Manager", LocalDate.of(2022, 2, 16), 60000, 45, p3, d1);
//		
//		p1.setEmp(e1);
//		p2.setEmp(e2);
//		p3.setEmp(e3);
//		
		
		
		
		
//		Set<Employee> temp = new HashSet<Employee>();
//		temp.add(e1);
//		temp.add(e2);
//		temp.add(e3);
//		
//		d1.setStaff(temp);
	
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		em.persist(e1);
		tx.commit();
		
		
	}
}

	
	

