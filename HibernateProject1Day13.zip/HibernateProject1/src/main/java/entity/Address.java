package entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="Address_TBL")
public class Address
{
	@Id
	@GeneratedValue
	@Column(name="add_id")
	private int addressId;
	
	@Column(name="houseno")
	private int houseno;
	
	
	@Column(name="area")
	private String area;
	
	
	@Column(name="city")
	private String city;
	
	@Column(name="state")
	private String state;
	

	@Column(name="pin")
	private int pin;
	
	@ManyToOne
	@JoinColumn(name="empNo")
	Employee emp;
	
	

	public Employee getEmp() {
		return emp;
	}
	public void setEmp(Employee emp) {
		this.emp = emp;
	}
	public Address( int houseno, String area, String city, String state, int pin) {
		super();
	
		this.houseno = houseno;
		this.area = area;
		this.city = city;
		this.state = state;
		this.pin = pin;
	}
	public int getHouseno() {
		return houseno;
	}
	public void setHouseno(int houseno) {
		this.houseno = houseno;
	}
	public int getAddressId() {
		return addressId;
	}
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	
	
	
}