package stratagy3;

import org.junit.jupiter.api.Test;

import dao.BaseDAO;
import dao.BaseDAOimpl;
import strategy3.BillingDetails;
import strategy3.BankAccount;
import strategy3.CreditCard;

public class StratagyThreeTest {

	BaseDAO baseDao = new BaseDAOimpl();
	
	
		
	@Test
	public void testAddAllAccountDetails()	{
		BillingDetails billObj = new BillingDetails();
		billObj.setAcnumber("5656121564");
		billObj.setOwner("John");
			
		BankAccount baObj = new BankAccount();
		baObj.setOwner("Jack");
		baObj.setAcnumber("123123123123");;
		baObj.setBankname("ICICI");
		baObj.setIfsccode("ICICI123");

		CreditCard ccObj = new CreditCard();
		ccObj.setOwner("Jane");
		ccObj.setAcnumber("6253584634545");
		ccObj.setCardType("VISA");
		ccObj.setExpiryMonth("June");
		ccObj.setExpiryYear("2024");
		
		baseDao.persist(billObj);
		baseDao.persist(baObj);
		baseDao.persist(ccObj);
		
	}
	
	
}
