package NamedQuery;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NamedQuery;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.junit.jupiter.api.Test;

import dao.BaseDAO;
import dao.BaseDAOimpl;
import entity.*;


public class NamedQueryTest {
	
	@Test
	public void showEmployeesAsPerSalary() {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("MyJPA"); 
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		//SQL :select * from EMP1 where sal>=3000 (Table name and column name)
		//JPQL:			from Emp e Where e.salary <=3000  (Poja class name and column name from pojo)
		String str = "FROM Emp e WHERE e.salary <=3000";
		
		String Token =  "allEmpEarning3kAbove";
		System.out.println("Named Query Token " +Token);
		Query query = entityManager.createNamedQuery(Token,Emp.class);
		
		query.setParameter("tempsal", 2000);
		List<Emp> staff = query.getResultList();
		
		for (Emp employee : staff) {
			System.out.println("Emp Number   : "+employee.getEmployeeNumber());
			System.out.println("Emp Name     : "+employee.getEmployeeName());
			System.out.println("Emp Manager  : "+employee.getMgr());
			System.out.println("Emp Job      : "+employee.getJob());
			System.out.println("Emp Hiredate : "+employee.getHiredate());
			System.out.println("Emp Salary   : "+employee.getSalary());
			System.out.println("Emp Comm     : "+employee.getCommision());
			System.out.println("Emp Deptno   : "+employee.getDepartmentNumber());
			System.out.println("------------------------");
		}
	}
}