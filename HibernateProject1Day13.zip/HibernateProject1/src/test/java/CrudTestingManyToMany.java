import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.junit.jupiter.api.Test;

import entity.Customer;
import entity.Department;
import entity.Employee;
import entity.Passport;
import entity.Project;
import entity.Subscription;

public class CrudTestingManyToMany {

	

	EntityManagerFactory emf;
	EntityManager em ;
	public CrudTestingManyToMany()
	{
		System.out.println("CrudTesting()....");
		// TODO Auto-generated method stub
				System.out.println("Trying to read persistence.xml file...");
				
				//3
				this.emf = Persistence.createEntityManagerFactory("MyJPA");
				System.out.println("EntityManagerFactory created....");
				
				this.em = emf.createEntityManager();
				System.out.println("EntityManager created....");

	}
	
	@Test
	public void createCustomerTest()
	{
		Customer cust1 = new Customer();
		cust1.setCustomerId(123);
		cust1.setCustomerName("Jack");
		cust1.setEmailAddress("jack@gmail.com");
		
		Customer cust2 = new Customer();
		cust2.setCustomerId(223);
		cust2.setCustomerName("Jhil");
		cust2.setEmailAddress("jhil@gmail.com");
		
		Customer cust3 = new Customer();
		cust3.setCustomerId(323);
		cust3.setCustomerName("jeny");
		cust3.setEmailAddress("jany@gmail.com");
		
		EntityTransaction tx = em.getTransaction();
		
		tx.begin();
		em.persist(cust1);
		em.persist(cust2);
		em.persist(cust3);
		tx.commit();
		
	}
	
	@Test
	public void createSubscriptionTest()
	{
		Subscription sub1 = new Subscription();
		sub1.setSubscriptionid(55);
		sub1.setSubname("Books");
		sub1.setSubtype("3Month");
		
		
		Subscription sub2 = new Subscription();
		sub2.setSubscriptionid(56);
		sub2.setSubname("CDs");
		sub2.setSubtype("2Month");
		
		Subscription sub3 = new Subscription();
		sub3.setSubscriptionid(57);
		sub3.setSubname("DVDs");
		sub3.setSubtype("1Month");
		
		
		
		EntityTransaction tx = em.getTransaction();
		
		tx.begin();
		em.persist(sub1);
		em.persist(sub2);
		em.persist(sub3);
		tx.commit();
		
	}
	
	
	@Test
	public void assignSubscriptionsToExsistingCustomer()
	{
		Customer c1= em.find(Customer.class, 223);
		
		Subscription sub1 = em.find(Subscription.class,55);
		Subscription sub2 = em.find(Subscription.class, 57);
		
		c1.getSubscriptiones().add(sub1);
		c1.getSubscriptiones().add(sub2);
		
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		em.merge(c1);
		tx.commit();
		
	}
	
	
	@Test
	public void assignCustomerToExsistingSubscription()
	{
		Customer c1= em.find(Customer.class, 223);
		Customer c2 = em.find(Customer.class, 323);
		
		Subscription sub1 = em.find(Subscription.class,56);
			
		sub1.getCustomers().add(c1);
		sub1.getCustomers().add(c2);
		
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		em.merge(sub1);
		tx.commit();
		
	}
	
	@Test
	public void showSubscriptionNameByCustomerNameId()
	{
		Customer cust = em.find(Customer.class, 223);
		Set<Subscription> subs = cust.getSubscriptiones();
		
		for(Subscription subscription : subs)
		{
			System.out.println("Subscripiton Name :" +subscription.getSubname());
			System.out.println("Subscripiton Type :" +subscription.getSubtype());
			System.out.println("---------------");
			
		}
		
	}

}
