package strategy4;

import org.junit.jupiter.api.Test;

import dao.BaseDAO;
import dao.BaseDAOimpl;
import strategy4.BankAccount;
import strategy4.CreditCard;


public class StrategyFourTest {

	BaseDAO baseDao = new BaseDAOimpl();

	@Test
	public void testAddAllAccountDetails() {

		BankAccount baObj = new BankAccount();
		baObj.setOwner("Jack");
		baObj.setAcnumber("123123123123");
		
		baObj.setBankname("ICICI");
		baObj.setIfsccode("ICICI123");

		CreditCard ccObj = new CreditCard();
		ccObj.setOwner("Jane");
		ccObj.setAcnumber("6253584634545");
		ccObj.setCardType("VISA");
		ccObj.setExpiryMonth("June");
		ccObj.setExpiryYear("2024");

		baseDao.persist(baObj);
		baseDao.persist(ccObj);

	}

}
