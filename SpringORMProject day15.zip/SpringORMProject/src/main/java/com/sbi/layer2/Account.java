package com.sbi.layer2;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;
 

@Component
@Entity
@Table(name="account_tbl")
public class Account {
	
	
	@Id
	@GeneratedValue
	@Column(name="acc_no")
	private int accountnumber;
	
	@Column(name="acc_name")
	private String accountName;
	
	@Column(name="acc_bal")
	private float accountBalance;

	public int getAccountnumber() {
		return accountnumber;
	}

	public void setAccountnumber(int accountnumber) {
		this.accountnumber = accountnumber;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public float getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(float accountBalance) {
		this.accountBalance = accountBalance;
	}
	
	
	
	
	
}
