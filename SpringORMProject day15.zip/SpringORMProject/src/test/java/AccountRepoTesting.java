import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.sbi.layer2.Account;
import com.sbi.layer3.AccountRepository;


@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations="classpath:myspring.xml")
public class AccountRepoTesting {
	
	@Autowired
	AccountRepository accRepo;
	
	@Test
	public void CreateAccountTest()
	{
		Account accObj= new Account();
		accObj.setAccountName("Deepthi");
		accObj.setAccountBalance(80000f);
		accRepo.createAccount(accObj);
	}

}
