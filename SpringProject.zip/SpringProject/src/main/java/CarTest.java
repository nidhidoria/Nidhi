import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sbi.Car;
import com.sbi.Engine;
import com.sbi.Piston;

public class CarTest {

	public static void main(String[] args) {
		
	
		System.out.println("Begin Main");
//		Piston pst= new Piston("TwinSprak");
//		Engine eng = new Engine(pst);
//		Car myCar = new Car(eng);
		System.out.println("Trying to creater SpringContainer");
		ApplicationContext ctx = new ClassPathXmlApplicationContext("myspring.xml");
		System.out.println("SpringContainer created");
		
		Car myCar = (Car) ctx.getBean("a");
//		myCar.startTheCar();
//		myCar.stopTheCar();
//		CarFactory cf = new CarFactory();
//		Car myCar = cf.getCar();
//		myCar.startTheCar();
//		myCar.stopTheCar();
//		System.out.println("End Main");
//		
//		Eagle e = new Eagle();
//		Tiger t = new Tiger();
//		Lotus l = new Lotus();
		}

}

//class CarFactory
//{
//	public Car getCar() {
//		Piston pst= new Piston("TwinSprak");
//		Engine eng = new Engine(pst);
//		Car tempCar= new Car(eng);
//		return tempCar;
//	}
//
//}