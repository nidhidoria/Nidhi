package com.sbi.emp;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

//1. create a pojo

/*
 * create table emp_tbl
 * (
 * 		emp_no int primary key,
 * 		emp_name varchar(20),
 * 		emp_job varchar(20),
 * 		emp_doj date,
 * 		emp_sal int,
 * );
 * 
 * 		Object	Relation	Mapping
 */

public class Employee {
	
	private int employeeNumber;
	private String name;
	private String job;
	private Integer mgr;
	private LocalDate joiningDate;
	private double salary;
	private Integer comm;
	private Integer deptno;
	public int getEmployeeNumber() {
		return employeeNumber;
	}
	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public Integer getMgr() {
		return mgr;
	}
	public void setMgr(Integer mgr) {
		this.mgr = mgr;
	}
	public LocalDate getJoiningDate() {
		return joiningDate;
	}
	public void setJoiningDate(LocalDate joiningDate) {
		this.joiningDate = joiningDate;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public Integer getComm() {
		return comm;
	}
	public void setComm(Integer comm) {
		this.comm = comm;
	}
	public Integer getDeptno() {
		return deptno;
	}
	public void setDeptno(Integer deptno) {
		this.deptno = deptno;
	}
	@Override
	public String toString() {
		return "Employee [employeeNumber=" + employeeNumber + ", name=" + name + ", job=" + job + ", mgr=" + mgr
				+ ", joiningDate=" + joiningDate + ", salary=" + salary + ", comm=" + comm + ", deptno=" + deptno + "]";
	}
	
	
	
	
	
	
}

