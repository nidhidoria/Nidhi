package com.sbi.level2;

public class Car {
	
		Engine  engine;
		public void setEngine(Engine ref )
		{
			System.out.println("Car() Constructer..level2.");
			engine = ref;
			
		}
		
		public void startTheCar() {
			
			
			engine.startEngine();
			System.out.println("Car Strted...");
		}
		
		public void stopTheCar() {
			
			engine.stopEngine();
			System.out.println("Car is Stopped...");
		}
		
		
}
