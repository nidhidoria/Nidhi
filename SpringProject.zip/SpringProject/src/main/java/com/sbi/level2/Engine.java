package com.sbi.level2;

public class Engine {
	
	Piston pist;
	
	public void setPiston(Piston ref) {
		System.out.println("Engine() Constructor..level2.");
		pist=ref;
		
	}

	
	public void startEngine() {
		System.out.println("Starting the Engine..");
		pist.firePiston();
	}
	
	
	public void stopEngine() {
		System.out.println("Stopping the Engine..");
	}
	
	

}
