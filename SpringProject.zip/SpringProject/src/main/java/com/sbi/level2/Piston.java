package com.sbi.level2;


public class Piston {
	
	public String pistonType;
	public void setPistonType(String pt)
	{
		System.out.println("Piston() constructor...level2.");
		pistonType = pt;
	}
	
	public void firePiston() {
		System.out.println("Piston is Fired " +pistonType);
	}

}
