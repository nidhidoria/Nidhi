package com.sbi;


public class Piston {
	
	public String pistonType;
	public Piston(String pt)
	{
		System.out.println("Piston() constructor....");
		pistonType = pt;
	}
	
	public void firePiston() {
		System.out.println("Piston is Fired " +pistonType);
	}

}
