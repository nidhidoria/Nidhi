package com.sbi;

public class Car {
	
		Engine  engine;
		public Car(Engine ref )
		{
			System.out.println("Car() Construction...");
			engine = ref;
			
		}
		
		public void startTheCar() {
			
			
			engine.startEngine();
			System.out.println("Car Strted...");
		}
		
		public void stopTheCar() {
			
			engine.stopEngine();
			System.out.println("Car is Stopped...");
		}
		
		
}
