package com.sbi;

public class Engine {
	
	Piston pist;
	
	public Engine(Piston ref) {
		System.out.println("Engine() Constructor...");
		pist=ref;
		
	}

	
	public void startEngine() {
		System.out.println("Starting the Engine..");
		pist.firePiston();
	}
	
	
	public void stopEngine() {
		System.out.println("Stopping the Engine..");
	}
	
	

}
