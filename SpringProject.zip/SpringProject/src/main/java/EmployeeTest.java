import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sbi.emp.Employee;
import com.sbi.emp.EmployeeService;
import com.sbi.level2.*;


public class EmployeeTest {

	public static void main(String[] args) {
		
	
		System.out.println("Begin Main");
//		Piston pst= new Piston("TwinSprak");
//		Engine eng = new Engine(pst);
//		Car myCar = new Car(eng);
	//	System.out.println("Trying to creater SpringContainer with myspring2.xml");
		ApplicationContext ctx = new ClassPathXmlApplicationContext("myspring3.xml");
		System.out.println("SpringContainer created");
		
		EmployeeService empServ = (EmployeeService) ctx.getBean("myEmpServ");
//		myCar.startTheCar();
//		myCar.stopTheCar();
//		CarFactory cf = new CarFactory();
//		Car myCar = cf.getCar();
//		myCar.startTheCar();
//		myCar.stopTheCar();
		List<Employee> emp1 = empServ.getEmployees();
		
		for (Employee employee : emp1) {
			
			System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++");
			System.out.println("Employee No :" +employee.getEmployeeNumber());
			System.out.println("Employee Name :" +employee.getName());
			System.out.println("Employee Job :" +employee.getJob());
			System.out.println("Employee Mgr :" +employee.getMgr());
			System.out.println("Employee Joining Date :" +employee.getJoiningDate());
			System.out.println("Employee Salary :" +employee.getSalary());
			System.out.println("Employee Commision :" +employee.getComm());
			System.out.println("Employee Dept No :" +employee.getDeptno());
			System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++");
			
		}
//		
//		Eagle e = new Eagle();
//		Tiger t = new Tiger();
//		Lotus l = new Lotus();
		}

}

//class CarFactory
//{
//	public Car getCar() {
//		Piston pst= new Piston("TwinSprak");
//		Engine eng = new Engine(pst);
//		Car tempCar= new Car(eng);
//		return tempCar;
//	}
//
//}