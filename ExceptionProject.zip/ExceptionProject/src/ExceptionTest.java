import java.util.InputMismatchException;
import java.util.Scanner;

public class ExceptionTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Line1");
		System.out.println("Line2");
		System.out.println("Line3");
		
		Scanner scan= new Scanner(System.in);
		
		try
		{		
			System.out.println("Enter Value of X : " );
			int x = scan.nextInt();
			System.out.println("X : " +x);
			
			System.out.println("Enter Value of Y : " );
			int y = scan.nextInt();
			System.out.println("Y : " +y);
			
			float z = x / y;
			String str =  null;
			//System.out.println(str.toUpperCase()+ "Division is " +z);  //Null Pointer Exception
			System.out.println("Division is " +z );
		}
		catch(InputMismatchException e)
		{
			System.out.println("Please enter Number " +e);
		}
		catch(ArithmeticException e)
		{
			System.out.println("Please enter Nonzero value for Y " +e);
		}
		catch(NullPointerException e)
		{
			System.out.println("Null Pointer Exception " +e);
		}
		catch(RuntimeException e)
		{
			System.out.println("Some Runtime error " +e);
		}
		catch(Throwable e)
		{
			System.out.println("Some Other error" +e);
		}
						
		System.out.println("Line4");
		System.out.println("Line5");
		System.out.println("Line6");
		
	}

}
