
public class DogExceptionTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Main Constructer Begin");
		Dog dogObj1;
		try {
			dogObj1 = new Dog(-5,"Bruno");
			System.out.println("Dog is " +dogObj1);
		} catch (DogAgeExceedExeception e) {
			// TODO Auto-generated catch block
			//	e.printStackTrace();
			System.out.println("Handler 1 : Exception in Dog Age " +e);
		} catch (DogAgeInNegetiveExeception e) {
			// TODO Auto-generated catch block
			System.out.println("Handler 2 : Exception in Dog Age "+e);
			
		} catch (DogNameInvalidExeception e) {
			// TODO Auto-generated catch block
			System.out.println("Handler 3 : Exception in Dog Name "+e);
		}
		finally
		{
			System.out.println("Finally Executed");
		}
	
	}

}

class Dog
{
  int age;
  String dname;
  
  public Dog(int age, String dname) throws DogAgeExceedExeception,DogAgeInNegetiveExeception,DogNameInvalidExeception
  {
	super();
	System.out.println("Dog Constructer Begin..");
	
	if(age>15)
	{
		throw new DogAgeExceedExeception("Dog's age cannot exceed 15");
	}
	else if (age < 0)
	{
		throw new DogAgeInNegetiveExeception("Dog's Age can not be in negetive");
	}	
	else
		this.age = age;
	
	if(dname.matches("[a-zA-Z]+"))
	{
		this.dname = dname;
	}
	else
	{
		throw new DogNameInvalidExeception("Dogs name is Invalid");
	}
	
	
	System.out.println("Dog Constructer Finished..");
  }

  
  
  	@Override
  	public String toString() {
  		return "dog [age=" + age + ", dname=" + dname + "]";
  }
  	
}  	
 class DogAgeExceedExeception extends Exception
 {
	 DogAgeExceedExeception(String str)
	 {
		 super(str);
	 }
 }
 class DogAgeInNegetiveExeception extends Exception
 {
	 DogAgeInNegetiveExeception(String str)
	 {
		 super(str);
	 }
 }
 class DogNameInvalidExeception extends Exception
 {
	 DogNameInvalidExeception(String str)
	 {
		 super(str);
	 }
 }
  
  
  
  


