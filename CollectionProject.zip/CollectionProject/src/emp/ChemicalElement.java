package emp;

public class ChemicalElement implements Comparable<ChemicalElement>
{
	int atomicbNumber;
	String atmoicName;
	String atomicFormula;
	float atomicWeight;
	public ChemicalElement(int atomicbNumber, String atmoicName, String atomicFormula, float atomicWeight) {
		super();
		this.atomicbNumber = atomicbNumber;
		this.atmoicName = atmoicName;
		this.atomicFormula = atomicFormula;
		this.atomicWeight = atomicWeight;
	}
	@Override
	public String toString() {
		return "ChemicalElement [atomicbNumber=" + atomicbNumber + ", atmoicName=" + atmoicName + ", atomicFormula="
				+ atomicFormula + ", atomicWeight=" + atomicWeight + "]";
	}
	@Override
	public int compareTo(ChemicalElement o) {
		// TODO Auto-generated method stub
		System.out.println("Comparing Atomic Weight " +atomicWeight+ " of " +atmoicName+ " with atomic Weight of "
		+o.atmoicName+"  which is " +o.atomicWeight);
		return Float.compare(atomicWeight, o.atomicWeight);
	}
	
	
}