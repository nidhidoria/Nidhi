package emp;

import java.util.Objects;

public class Book
{
	String bisbnno;
	String bname;
	String author;
	int noOfPages;
	int edition;
	float price;
	public Book(String bisbnno, String bname, String author, int noOfPages, int edition, float price) {
		super();
		this.bisbnno = bisbnno;
		this.bname = bname;
		this.author = author;
		this.noOfPages = noOfPages;
		this.edition = edition;
		this.price = price;
	}
	@Override
	public String toString() {
		return "Book [bisbnno=" + bisbnno + ", bname=" + bname + ", author=" + author + ", noOfPages=" + noOfPages
				+ ", edition=" + edition + ", price=" + price + "]";
	}
//	
	@Override
	public int hashCode() {
		return Objects.hash(bisbnno);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Book other = (Book) obj;
		return Objects.equals(bisbnno, other.bisbnno);
	}
	
	
}	
