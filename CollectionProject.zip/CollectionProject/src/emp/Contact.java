package emp;

public class Contact
{
	String cname;
	String mnumber;
	String email;
	public Contact(String cname, String mnumber, String email) {
		super();
		this.cname = cname;
		this.mnumber = mnumber;
		this.email = email;
	}
	@Override
	public String toString() {
		return "Contact [cname=" + cname + ", mnumber=" + mnumber + ", email=" + email + "]";
	}
	
	
	
	
}