package emp;

public class Employee implements Comparable<Employee>
{
	int Eid;
	String Ename;
	float salary;
	public Employee(int eid, String ename, float salary) {
		super();
		Eid = eid;
		Ename = ename;
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [Eid=" + Eid + ", Ename=" + Ename + ", salary=" + salary + "]";
	}
	@Override
	
	
	public int compareTo(Employee o) {
		// TODO Auto-generated method stub
		System.out.println("Comparing "+Ename+ "'s ID " +Eid+ " With ID of " +o.Ename+ " which is " +o.Eid);
		return Integer.compare(Eid, o.Eid);
	}
//	public int compareTo(Employee o) {
//		// TODO Auto-generated method stub
//		System.out.println("Comparing "+Ename+ "'s salary " +salary+ " With salary of " +o.Ename+ " which is " +o.salary);
//		return Float.compare(salary, o.salary);
//	}
	
	
}