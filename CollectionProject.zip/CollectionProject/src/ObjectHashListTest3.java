import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.TreeSet;

import emp.Employee;

public class ObjectHashListTest3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e1 = new Employee(18, "Vrudhi", 16000);
//	ArrayList<Employee> staff = new ArrayList<Employee>();
//	LinkedList<Employee> staff = new LinkedList<Employee>();
	HashSet<Employee> staff = new HashSet<Employee>();
//	TreeSet<Employee> staff = new TreeSet<Employee>();
	
	staff.add(new Employee(11, "Nidhi",10000));
	staff.add(new Employee(12, "Siddhi",11000));
	staff.add(new Employee(13, "Riddhi",12000));
	staff.add(new Employee(14, "Vidhi",13000));
	staff.add(e1);
	staff.add(new Employee(15, "Dhara",14000));
		
//	for(int i = 0 ; i< staff.size(); i++)
//	{
//		System.out.println("Staff: " +staff.get(i));
//	}
//	
//	System.out.println("Adding next element");
//	for(int i = 0 ; i< staff.size(); i++)
//	{
//		System.out.println("Printing Staff again : " +staff.get(i));
//	}
//
//	}
	
	
	Iterator<Employee> iterator = staff.iterator();
	while(iterator.hasNext())
	{
	Employee theEmp  = iterator.next();
	System.out.println(" Deatails of  "  +theEmp);
	
	}
	

}
}

//class Employee
//{
//	int Eid;
//	String Ename;
//	float salary;
//	public Employee(int eid, String ename, float salary) {
//		super();
//		Eid = eid;
//		Ename = ename;
//		this.salary = salary;
//	}
//	@Override
//	public String toString() {
//		return "Employee [Eid=" + Eid + ", Ename=" + Ename + ", salary=" + salary + "]";
//	}
//	
//	
//}
