import java.time.LocalDate;

public class Log
{
	String logType;
	LocalDate date;
	String name;
	public Log(String logType, LocalDate date, String name) {
		super();
		this.logType = logType;
		this.date = date;
		this.name = name;
	}
	@Override
	public String toString() {
		return "Log [logType=" + logType + ", date=" + date + ", name=" + name + "]";
	} 
	
	
	
	
}