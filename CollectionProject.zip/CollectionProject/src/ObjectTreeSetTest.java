import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.TreeSet;

import emp.Employee;

public class ObjectTreeSetTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e1 = new Employee(18, "Vrudhi", 16000);
//	ArrayList<Employee> staff = new ArrayList<Employee>();
//	LinkedList<Employee> staff = new LinkedList<Employee>();
//	HashSet<Employee> staff = new HashSet<Employee>();
	TreeSet<Employee> staff = new TreeSet<Employee>();
	
	System.out.println("Adding Object 1 " );
	staff.add(new Employee(45, "Nidhi",10000));
	
	System.out.println("Adding Object 2 " );
	staff.add(new Employee(12, "Siddhi",11000));
	
	System.out.println("Adding Object 3 " );
	staff.add(new Employee(4, "Riddhi",12000));
	
	System.out.println("Adding Object 4 " );
	staff.add(new Employee(16, "Vidhi",13000));
	
	System.out.println("Adding Object 5 " );
	staff.add(e1);
	
	System.out.println("Adding Object 6 " );
	staff.add(new Employee(95, "Dhara",14000));
	
	System.out.println("Adding Object 7 " );
	staff.add(new Employee(65, "Dhara",14000));
	
	System.out.println("Adding Object 8 " );
	staff.add(new Employee(20, "Dhara",14000));
	
	System.out.println("Adding Object 9 " );
	staff.add(new Employee(73, "Dhara",14000));
		
//	for(int i = 0 ; i< staff.size(); i++)
//	{
//		System.out.println("Staff: " +staff.get(i));
//	}
//	
//	System.out.println("Adding next element");
//	for(int i = 0 ; i< staff.size(); i++)
//	{
//		System.out.println("Printing Staff again : " +staff.get(i));
//	}
//
//	}
	
	
	Iterator<Employee> iterator = staff.iterator();
	while(iterator.hasNext())
	{
	Employee theEmp  = iterator.next();
	System.out.println(" Deatails of Employee "  +theEmp);
	
	}
	

}
}

//class Employee
//{
//	int Eid;
//	String Ename;
//	float salary;
//	public Employee(int eid, String ename, float salary) {
//		super();
//		Eid = eid;
//		Ename = ename;
//		this.salary = salary;
//	}
//	@Override
//	public String toString() {
//		return "Employee [Eid=" + Eid + ", Ename=" + Ename + ", salary=" + salary + "]";
//	}
//	
//	
//}
