import emp.Employee;

public class ObjectArrayTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Employee staff[] = new Employee[5];
	staff[0] = new Employee(11, "Nidhi",10000);
	staff[1] = new Employee(12, "Siddhi",11000);
	staff[2] = new Employee(13, "Riddhi",12000);
	staff[3] = new Employee(14, "Vidhi",13000);
	staff[4] = new Employee(15, "Dhara",14000);
		
	for(int i = 0 ; i< staff.length; i++)
	{
		System.out.println("Staff: " +staff[i]);
	}
	
	}

}


