import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.TreeSet;

import emp.Book;
import emp.ChemicalElement;
import emp.Contact;
import emp.Employee;

public class CollectionAssgnment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<Log> log = new ArrayList<Log>();
		log.add(new Log("Dialed", LocalDate.now(), "Jhil"));
		log.add(new Log("Dialed", LocalDate.of(2022,6,12), "Jack"));
		log.add(new Log("Missed", LocalDate.of(2022,3,28), "Nil"));
		log.add(new Log("Received", LocalDate.of(2022, 3, 27), "Niki"));
		
	
		Iterator<Log> iterator = log.iterator();
		while(iterator.hasNext())
		{
		Log lg  = iterator.next();
		System.out.println(" Details of Logs are "  +lg);
		
		}
		System.out.println("******************************************************");
	  			
		LinkedList<Contact> contact = new LinkedList<Contact>();
		contact.add(new Contact("Jack","9856321080", "jack@gmail.com"));
		contact.add(new Contact("Nidhi","9856321020", "nidhi@gmail.com"));
		contact.add(new Contact("Herry","7453621052", "herry@gmail.com"));
		contact.add(new Contact("heli","7456320185", "heli@gmail.com"));
		
		Iterator<Contact> iterator1 = contact.iterator();
		while(iterator1.hasNext())
		{
		Contact ct  = iterator1.next();
		System.out.println(" Details of Contact are "  +ct);
		
		}
		
		System.out.println("******************************************************");
		HashSet<Book> book = new HashSet<Book>();
		Book b1 = new Book("9728-5236-853","Alchemist", "paulo calho",200,2017,300f );
		book.add(b1);
		
		Book b2 = new Book("9728-5236-854","Alchemist", "paulo calho",200,2017,300f );
		book.add(b2);
		Book b3 = b1;  
		book.add(b3); //Will not ADD this object
		book.add(new Book("8228-9563-42","Power OF Now", "Echart Tolly",300,2018,500f));
		book.add(new Book("7412-3562-856","5AM Club", "Robin Sharma",250,2019,300f ));
		book.add(new Book("0213-6532-963","Anviksha", "Jigna Patel",310,2020,450f ));
		book.add(new Book("3652-3625-741","3Idiots", "Chetan Bhagat",510,2019,250f ));
		
		Iterator<Book> iterator2 = book.iterator();
		while(iterator2.hasNext())
		{
		Book bk  = iterator2.next();
		System.out.println(" Details of Book are "  +bk);
		}

		
		
		
		
		
		
		System.out.println("******************************************************");
		
		
		
		TreeSet<ChemicalElement> chmElemnt = new TreeSet<ChemicalElement>();
		System.out.println("Adding Element 1 " );
		chmElemnt.add(new ChemicalElement(1, "Hydrogen","H",1.00797f));
		
		System.out.println("Adding Element 2 " );
		chmElemnt.add(new ChemicalElement(2, "Helium","He",4.00260f));
		
		System.out.println("Adding Element 3 " );
		chmElemnt.add(new ChemicalElement(8, "Oxygen","O",15.999f));
		
		System.out.println("Adding Element 4 " );
		chmElemnt.add(new ChemicalElement(13, "Aluminum","Al",26.9815f));
		
		System.out.println("Adding Element 5 " );
		chmElemnt.add(new ChemicalElement(26, "Iron","Fe",55.847f));
		
		System.out.println("Adding Element 6 " );
		chmElemnt.add(new ChemicalElement(16, "Sulfer","S",32.06f));
		
		System.out.println("Adding Element 7 " );
		chmElemnt.add(new ChemicalElement(94, "Plutonium","Pu",242f));
		
		Iterator<ChemicalElement> iterator4 = chmElemnt.iterator();
		while(iterator4.hasNext())
		{
		ChemicalElement chel  = iterator4.next();
		System.out.println(" Deatails of Chemical Element "  +chel);
		
		}
		
}
}
















