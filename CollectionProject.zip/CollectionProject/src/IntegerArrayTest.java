
public class IntegerArrayTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int rollno1[] = {10,20,30,40,50};
		
		int rollno2[] = new int[20];
		rollno2[0] = 30;
		rollno2[1]= 40;
		rollno2[2]= 90;
		rollno2[3]= 60;
		rollno2[4]= 50;
		rollno2[6]= 80;
		rollno2[11]= 10;
		rollno2[19]= 70;
		
			
		for(int i=0;i<rollno1.length;i++)
		{
			System.out.println("Roll no : " +rollno1[i]);
		}
		System.out.println("*************************************");
		for(int i=0;i<rollno2.length;i++)
		{
			System.out.println("Roll no : " +rollno2[i]);
		}
		
		
		try
		{
		System.out.println("Trying to set other value");	
		rollno1[5] = 5;  // ArrrayIndexOutofBound
		rollno2[20]= 100; //// ArrrayIndexOutofBound
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Index out of Bound" +e);
		}
		
		
	}

}
