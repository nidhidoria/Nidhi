import { newapplicant } from "./newapplicant";

export class address{

     addressId : number =0;
	addressType : string="";
	area : string ="";
	street: string ="";
	city: string ="";
	 state: string ="";
	 country: string ="";
      pin :number=0;
    applicant : newapplicant = new newapplicant();
}