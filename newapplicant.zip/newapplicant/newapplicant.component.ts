import { Component, OnInit } from '@angular/core';
import { NewapplicantService } from '../newapplicant.service';
import { newapplicant } from './newapplicant';

@Component({
  selector: 'app-newapplicant',
  templateUrl: './newapplicant.component.html',
  styleUrls: ['./newapplicant.component.css']
})
export class NewapplicantComponent implements OnInit {

  constructor(private applicantserviceObj : NewapplicantService) { }
  applicantArray : newapplicant[]=[];
  ngOnInit(): void {
    this.showAllApplicants();
  }

  showAllApplicants()
  {
    console.log("showAllApplicants() invoking loadAllapplicantsService method")
    this.applicantserviceObj.loadAllapplicantsService().subscribe(
      (data:newapplicant[]) =>
      {
        this.applicantArray=data;
      },
      (err) =>
      {
        console.log(err);
      }

    )
  }

}
