import { address } from "./address";

export class newapplicant
{

      applicantId :number=0
	  accountType: string ="";
	  applicantName: string ="";
	  applicantFatherName: string ="";
	  applicantDateofBirth: Date = new Date();
	  applicantMobile: string ="";
	  married: string ="";			//isMarried(), setMarried()
	  applicantOccupation: string ="";  
	    addressList: address[]=[];
	  adhaarnumber: string =""; //address proof
	  panCard: string ="";	//pan number
	  photo: string ="";		//photo
	  annualIncome:number=0;
	  applicationStatus: string ="";
}