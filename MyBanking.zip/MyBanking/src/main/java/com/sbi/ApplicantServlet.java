package com.sbi;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sbi.layer2.AccountType;
import com.sbi.layer2.Address;
import com.sbi.layer2.Applicant;
import com.sbi.layer2.ApplicationStatus;
import com.sbi.layer4.AccountService;
import com.sbi.layer4.ApplicantService;
import com.sbi.layer4.ApplicantServiceImpl;


@WebServlet("/applicant") // Step2
public class ApplicantServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	

	ApplicantService appService = new ApplicantServiceImpl();
    public ApplicantServlet() {
        super();
       ApplicationContext ctx = new ClassPathXmlApplicationContext("myspring.xml");
       System.out.println("ctx " +ctx);
    }

	
    //step 3
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	response.getWriter().append("Served at: ").append(request.getContextPath());
		
		response.setContentType("text/html");
		String acType= request.getParameter("accounttype");
		String acHolderName= request.getParameter("app_name");
		String acHolderFatherName=  request.getParameter("app_fathername");
		String acHolderdob= request.getParameter("app_dob");
		String acHoldermobile= request.getParameter("app_mobile");
		String acHolderMaritialStatus= request.getParameter("maritalstatus");
		String acHolderOccupation=  request.getParameter("occupation");
		
		String acpermarea=  request.getParameter("app_p_area");
		String acpermstreet= request.getParameter("app_p_street");
		String acpermcity=  request.getParameter("app_p_city");
		String acpermstate= request.getParameter("app_p_state");
		String acpermcountry= request.getParameter("app_p_country");
		String acpermpin= request.getParameter("app_p_pin");
		String accorarea= request.getParameter("app_c_area");
		String accorstreet=  request.getParameter("app_c_street");
		String accorcity= request.getParameter("app_c_city");
		String accorstate= request.getParameter("app_c_state");
		String accorcountry=  request.getParameter("app_c_country");
		String accorpin=  request.getParameter("app_c_pin");
		String acaadharno=  request.getParameter("app_aadharno");
		String acpancard=  request.getParameter("app_pancard");
		String acphoto= request.getParameter("app_photo");
		String acannualincome=request.getParameter("app_annualIncome");
		
		
		Applicant applicant = new Applicant();
		
		applicant.setAccountType(acType); //1
		applicant.setApplicantName(acHolderName); //2
		applicant.setApplicantFatherName(acHolderFatherName); //3
		applicant.setApplicantMobile(acHoldermobile); //4
		LocalDate birtDate = LocalDate.parse(acHolderdob); 
		applicant.setApplicantDateofBirth(birtDate);//5
		
		applicant.setMarried(acHolderMaritialStatus); 
		
		applicant.setApplicantOccupation(acHolderOccupation);
		
		
		Address parmenentAddr = new Address();
		parmenentAddr.setAddressType("Parmenent");
		parmenentAddr.setStreet(acpermstreet);
		parmenentAddr.setArea(acpermarea);
		parmenentAddr.setCity(acpermcity);
		parmenentAddr.setState(acpermstate);
		parmenentAddr.setCountry(acpermcountry);
		parmenentAddr.setPin(Integer.parseInt(acpermpin));
		parmenentAddr.setApplicant(applicant);
		
		Address coorospondanceAddr = new Address();
		coorospondanceAddr.setAddressType("Corospondance");
		coorospondanceAddr.setStreet(accorstreet);
		coorospondanceAddr.setArea(accorarea);
		coorospondanceAddr.setCity(accorcity);
		coorospondanceAddr.setState(accorstate);
		coorospondanceAddr.setCountry(accorcountry);
		coorospondanceAddr.setPin(Integer.parseInt(accorpin));
		coorospondanceAddr.setApplicant(applicant);
		
		List<Address> addlist = new ArrayList<Address>();
		addlist.add(coorospondanceAddr);
		addlist.add(parmenentAddr);
		applicant.setAddressList(addlist);
		
		applicant.setAdhaarnumber(acaadharno);
		applicant.setPanCard(acpancard);
		applicant.setPhoto(acphoto);
		applicant.setAnnualIncome(Double.parseDouble(acannualincome));
		applicant.setApplicationStatus(ApplicationStatus.APPLIED);
		
		
		appService.createApplicationService(applicant);
		PrintWriter pw = response.getWriter();
		pw.println("<h2> Thank You " +acHolderName+" </h2>");
		pw.println("<h2> Application Successfully Submitted </h2>");
		pw.println("<a href='http://192.168.0.120:8080/MyBanking/'>Home</a>");
	//	String clientAddres = request.getRemoteAddr();
		System.out.println(acHolderName+ " has submitted the Application");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}
	
	
