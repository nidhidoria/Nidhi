package com.sbi.layer3;

import javax.transaction.Transactional;
import java.util.List;

import org.springframework.stereotype.Repository;
import javax.transaction.Transactional;

import com.sbi.layer2.Account;
import com.sbi.layer2.Applicant;


@Repository
public class ApplicantRepositoryImpl extends BaseRepositoryimpl implements ApplicantRepository
{
	//@Transactional
	public void createApplication(Applicant applicant) {
		// TODO Auto-generated method stub
		super.persist(applicant);
	}

	@Transactional
	public void modifyApplication(Applicant applicant) {
		// TODO Auto-generated method stub
		super.merge(applicant);
	}
	
	@Transactional
	public void removeApplication(int applicantId) {
		// TODO Auto-generated method stub
		Applicant appObj = super.find(Applicant.class, applicantId);
		super.remove(applicantId);
	}

	@Transactional
	public Applicant findApplication(int applicantId) {
		// TODO Auto-generated method stub
		
		return super.find(Applicant.class,applicantId);
	}

	public List<Applicant> findAllApplicants() {
		// TODO Auto-generated method stub
		return super.findAll("Applicant");
	}

	
	
}
