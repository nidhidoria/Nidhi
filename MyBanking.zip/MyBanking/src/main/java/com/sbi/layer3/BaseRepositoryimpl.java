package com.sbi.layer3;

import java.io.Serializable;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import javax.transaction.Transactional;

@Repository
public class BaseRepositoryimpl implements BaseRepository {
		
	//@PersistenceContext(unitName= "MyJPA")
	EntityManager entityManager;
	
	public BaseRepositoryimpl()
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("MyJPA");	
		entityManager = emf.createEntityManager();
		System.out.println("BaseREpoImpl()..........." +entityManager);
	}
	
	
	public void persist(Object obj) //user defined function
	{
		EntityTransaction tx = entityManager.getTransaction();
		tx.begin();
		entityManager.persist(obj);
		tx.commit();
	}
	

	public void remove(Object obj)   //user defined function
	{
		EntityTransaction tx = entityManager.getTransaction();
		tx.begin();	
		entityManager.remove(obj);
		tx.commit();//ORM's remove 
	}
	

	public void merge(Object obj) //user defined function
	{
		EntityTransaction tx = entityManager.getTransaction();
		tx.begin();		
		entityManager.merge(obj);
		tx.commit();	
	}
	

	public <AnyType> AnyType find(Class<AnyType> classname,Serializable primaryKey)  //user defined function
	{
			AnyType e = entityManager.find(classname, primaryKey);
			return e;
	}
	


	public <AnyType> List<AnyType> findAll(String entityName) 
	{
			Query query = entityManager.createQuery("from " +entityName);
			return query.getResultList();
	}

	
	
	
	
	
}
