package com.sbi.layer4;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.layer2.Account;
import com.sbi.layer2.Applicant;
import com.sbi.layer2.ApplicationStatus;
import com.sbi.layer3.AccountRepository;
import com.sbi.layer3.ApplicantRepository;

@Service
public class AccountServiceImpl implements AccountService
{
		@Autowired
		ApplicantRepository appRepo;
		
		@Autowired
		AccountRepository accRepo;

		public void openBankAccountService(int applicantId) {
			
			Applicant applicant = appRepo.findApplication(applicantId);
			
			if(applicant != null)
			{
			Account account = new Account();
			account.setAccountName(applicant.getApplicantName());
			account.setAccountBalance(5000);
			account.setApplicant(applicant);
			
			applicant.setApplicationStatus(ApplicationStatus.APPROVED);
			
			appRepo.modifyApplication(applicant);
			
			accRepo.createAccount(account);
			}
			else
			{
				throw new RuntimeException("Application id Not Found.." +applicantId); 
				
			}
			
			
		}
		
		
}
