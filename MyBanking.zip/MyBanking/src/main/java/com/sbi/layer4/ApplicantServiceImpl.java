package com.sbi.layer4;

import org.springframework.stereotype.Service;

import com.sbi.layer2.Applicant;
import com.sbi.layer3.ApplicantRepository;
import com.sbi.layer3.ApplicantRepositoryImpl;

@Service
public class ApplicantServiceImpl implements ApplicantService {
	
	
	
	ApplicantRepository appRepo = new ApplicantRepositoryImpl();
	

	public void createApplicationService(Applicant app) {
		
		appRepo.createApplication(app);
		System.out.println("ApplicantServiceImpl.... created the Applicant");
	}

	

	
	
	
}
