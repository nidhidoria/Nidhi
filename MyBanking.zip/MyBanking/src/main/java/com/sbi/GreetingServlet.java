package com.sbi;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class GreetingServlet
 */
@WebServlet("/greet")
public class GreetingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GreetingServlet() {
        super();
       System.out.println("GreetingServlet() Constructor.....");
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		System.out.println("Init() Constructor.....");
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		System.out.println("Destroy() Constructor.....");
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doGet() Constructor.........");
		
		LocalDateTime cureDateTime = LocalDateTime.now();
		
		int hod = cureDateTime.getHour();

		String greetMsg="";
		
		if(hod >4 && hod <=12)
		{
			greetMsg = "Good Morning,Have a  Nice Day";
		}
		else if (hod >12 && hod <=17)
		{
			greetMsg = "Good Noon";
		}
		else if (hod >17 && hod <=20)
		{
			greetMsg = "Good Eve";
		}
		else if(hod >20 && hod <=24)
		{
			greetMsg = "Good Night";
		}
		
				
		String Yourname = request.getParameter("myname");
		PrintWriter pw = response.getWriter();
		String clientAddres = request.getRemoteAddr();
		pw.println("<h1>doGet is called from" +clientAddres+" Name is " +Yourname);
		pw.println("<h1>Hello user, " +Yourname+" "+greetMsg+ "</h1>");
		pw.println("<h1>Your Ip Address : " +clientAddres+ "</h1>");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		System.out.println("doPost() Constructor.........");
	}

}
