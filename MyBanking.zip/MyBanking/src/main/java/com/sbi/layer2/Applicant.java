package com.sbi.layer2;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name="applicant_tbl")
public class Applicant {
	
	
	@Id
	@GeneratedValue
	@Column(name="applicant_id")
	private int applicantId;
	
	@Column(name="account_type")
	private String accountType;
	
	@Column(name="applicant_name")
	private String applicantName;
	
	@Column(name="applicant_father")
	private String applicantFatherName;
	
//	@Column(name="applicant_dob")
//	private LocalDate applicantDateofBirth;
	
	@Column(name="applicant_mobile")
	private String applicantMobile;
	
	@Column(name="applicant_married")
	private String married;			//isMarried(), setMarried()
	
	@Column(name="applicant_occcupation")
	private String applicantOccupation;   
	
	@OneToMany(mappedBy = "applicant",cascade = CascadeType.ALL)	
	List<Address> addressList = new ArrayList<Address>();
	
	@Column(name="applicant_aadharno")
	private String adhaarnumber;  //address proof
	
	@Column(name="applicant_panno")
	private String panCard; 	//pan number
	
	@Column(name="applicant_photo")
	private String photo;		//photo
	
	@Column(name="applicant_anualincome")
	private double annualIncome;
	
	private String applicationStatus;   //APPLIED, IN_PROGRESS,APPROVED,REJECTED
	
	public String getApplicationStatus() {
	return applicationStatus;
	}

	public void setApplicationStatus(String applicationStatus) {
		this.applicationStatus = applicationStatus;
	}

	public int getApplicantId() {
		return applicantId;
	}

	public void setApplicantId(int applicantId) {
		this.applicantId = applicantId;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getApplicantName() {
		
		System.out.println("getname()");
		return applicantName;
	}

	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
		System.out.println("setname()");
	}

	public String getApplicantFatherName() {
		return applicantFatherName;
	}

	public void setApplicantFatherName(String applicantFatherName) {
		this.applicantFatherName = applicantFatherName;
		
	}

//	public LocalDate getApplicantDateofBirth() {
//		return applicantDateofBirth;
//	}
//
//	public void setApplicantDateofBirth(LocalDate applicantDateofBirth) {
//		this.applicantDateofBirth = applicantDateofBirth;
//	}

	public String getApplicantMobile() {
		return applicantMobile;
	}

	public void setApplicantMobile(String applicantMobile) {
		this.applicantMobile = applicantMobile;
	}

	public String  getMarried() {
		return married;
	}

	public void setMarried(String married) {
		this.married = married;
	}

	public String getApplicantOccupation() {
		return applicantOccupation;
	}

	public void setApplicantOccupation(String applicantOccupation) {
		this.applicantOccupation = applicantOccupation;
	}

	public List<Address> getAddressList() {
		return addressList;
	}

	public void setAddressList(List<Address> addressList) {
		this.addressList = addressList;
	}

	public String getAdhaarnumber() {
		return adhaarnumber;
	}

	public void setAdhaarnumber(String adhaarnumber) {
		this.adhaarnumber = adhaarnumber;
	}

	public String getPanCard() {
		return panCard;
	}

	public void setPanCard(String panCard) {
		this.panCard = panCard;
	}

	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public double getAnnualIncome() {
		return annualIncome;
	}

	public void setAnnualIncome(double annualIncome) {
		this.annualIncome = annualIncome;
	}
	
	
	
	
	
}
