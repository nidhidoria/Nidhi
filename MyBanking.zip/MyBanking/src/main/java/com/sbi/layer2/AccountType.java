package com.sbi.layer2;

public interface AccountType {

	String SAVINGS="Saving";
	String CURRENT="Current";
	String FIXED="Fixed Deposit";
	String RECURRING="Recurring Deposit";
}
