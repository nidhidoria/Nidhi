package com.sbi.layer5;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sbi.layer2.Applicant;

@Controller
@RequestMapping("/applicant")
public class ApplicantController {
	
	public ApplicantController()
	{
		System.out.println("ApplicantController() no-arg is called");
	}
	
	@RequestMapping("/apply")
	public String greet1()
	{
		System.out.println("in greet ");
	//	return "Welcome";
		return "ApplyForBankAccount";
	}
	
	@RequestMapping("/create")
	public String createApplicantData(Applicant appObj)
	{
		System.out.println("createApplicantData() invoke....."+appObj);
		return "create";
	}
}
