import java.time.LocalDate;
import java.util.ArrayList;

class Employee
{
	private int employeeNumber; //primary key
	private String employeeName;
	private LocalDate employeeJoining;
	private double employeeSalary;
	Passport passport= new Passport();
	ArrayList<Address> addressList = new ArrayList<Address>();
	ArrayList<Project> projectList= new ArrayList<Project>();
	public int getEmployeeNumber() {
		return employeeNumber;
	}
	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public LocalDate getEmployeeJoining() {
		return employeeJoining;
	}
	public void setEmployeeJoining(LocalDate employeeJoining) {
		this.employeeJoining = employeeJoining;
	}
	public double getEmployeeSalary() {
		return employeeSalary;
	}
	public void setEmployeeSalary(double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}
	public Passport getPassport() {
		return passport;
	}
	public void setPassport(Passport passport) {
		this.passport = passport;
	}
	public ArrayList<Address> getAddressList() {
		return addressList;
	}
	public void setAddressList(ArrayList<Address> addressList) {
		this.addressList = addressList;
	}
	public ArrayList<Project> getProjectList() {
		return projectList;
	}
	public void setProjectList(ArrayList<Project> projectList) {
		this.projectList = projectList;
	}
	@Override
	public String toString() {
		return "Employee [employeeNumber=" + employeeNumber + ", employeeName=" + employeeName + ", employeeJoining="
				+ employeeJoining + ", employeeSalary=" + employeeSalary + ", passport=" + passport + ", addressList="
				+ addressList + ", projectList=" + projectList + ", getEmployeeNumber()=" + getEmployeeNumber()
				+ ", getEmployeeName()=" + getEmployeeName() + ", getEmployeeJoining()=" + getEmployeeJoining()
				+ ", getEmployeeSalary()=" + getEmployeeSalary() + ", getPassport()=" + getPassport()
				+ ", getAddressList()=" + getAddressList() + ", getProjectList()=" + getProjectList() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
	
	
	
}